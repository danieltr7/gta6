ip addr add 192.168.56.105/24 dev enp0s8
ip link set enp0s8 up
apt install netplan.io
nano /etc/netplan/00-installer-config.yaml
ip a
nmcli connection add type ethernet ifname enp0s3 con-name "enp0s3" autoconnect yes
nmcli device set enp0s3 autoconnect yes
nmcli device set enp0s8 autoconnect yes
nmcli device connect enp0s3
nmcli device connect enp0s8
reboot
